declare module 'jsvectormap'
